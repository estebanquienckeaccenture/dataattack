# Databricks notebook source
#https://www.kaggle.com/datasets/rabisingh/symptom-checker/code?select=Testing.csv

# COMMAND ----------

import numpy as np
import pandas as pd
from sklearn import tree
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM hive_metastore.default.training_prognosis

# COMMAND ----------

training = _sqldf.toPandas()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM hive_metastore.default.testing_prognosis

# COMMAND ----------

testing = _sqldf.toPandas()

# COMMAND ----------

print(f"The shape of the training dataset is: {training.shape}")
print(f"The shape of the testing dataset is: {testing.shape}")

# COMMAND ----------

training.prognosis.value_counts()

# COMMAND ----------

X_train, X_val, y_train, y_val = train_test_split(training.drop(["prognosis"], axis=1), training["prognosis"], test_size=0.20, random_state=7)

# COMMAND ----------

X_train.replace(0, np.nan).isna().sum().sort_values()

# COMMAND ----------

clf = tree.DecisionTreeClassifier(max_depth=None, min_samples_split=2, min_samples_leaf=2,
                                  random_state=7, min_impurity_decrease=0.01)

clf = clf.fit(X_train, y_train)

# COMMAND ----------

clf.score(X_train, y_train)

# COMMAND ----------

y_predict = clf.predict(X_val)

# COMMAND ----------

accuracy_score(y_val, y_predict)

# COMMAND ----------

X_test = testing.drop(["prognosis"], axis=1)
y_test = testing["prognosis"]

y_predict = clf.predict(X_test)

# COMMAND ----------

accuracy_score(y_test, y_predict)

# COMMAND ----------

